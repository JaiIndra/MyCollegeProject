<?php

$connect = mysqli_connect("localhost", "root", "", "javapoint");
$message = '';

if(isset($_POST["upload"]))
{
 if($_FILES['product_file']['name'])
 {
  $filename = explode(".", $_FILES['product_file']['name']);
  if(end($filename) == "csv")
  {
   $handle = fopen($_FILES['product_file']['tmp_name'], "r");
   while($data = fgetcsv($handle))
   {
    $Htno = mysqli_real_escape_string($connect, $data[0]);
    $Subcode = mysqli_real_escape_string($connect, $data[1]);  
     $Subname = mysqli_real_escape_string($connect, $data[2]);
      $Grade = mysqli_real_escape_string($connect, $data[3]);
    $Credits = mysqli_real_escape_string($connect, $data[4]);
    $query = "UPDATE `4-1results` SET `Subname`='$Subname',`Grade`='$Grade',`Credits`='$Credits' WHERE `Subcode` ='$Subcode' AND `Htno`='$Htno'";

    mysqli_query($connect, $query);
   }
   fclose($handle);
   header("location: 4-1update.php?updation=0");
  }
  else
  {
   $message = '<label class="text-danger">Please Select CSV File only</label>';
  }
 }
 else
 {
  $message = '<label class="text-danger">Please Select File</label>';
 }
}

if(isset($_GET["updation"]))
{
 $message = '<label class="text-success">Product Updation Done</label>';
}

$query = "SELECT * FROM `4-1results`";
$result = mysqli_query($connect, $query);
?>
<!DOCTYPE html>
<html>
 <head>
  <title>Update Mysql Database through Upload CSV File using PHP</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br /><div class="item"><a href="logout.php"><i class="fas fa-info-circle"></i>Logout</a></div>
  <div class="container">
   <h2 align="center"> 4-1 Results Update</a></h2>
   <br />
   <form method="post" enctype='multipart/form-data'>
    <p><label>Please Select File(Only CSV Formate)</label>
    <input type="file" name="product_file" /></p>
    <br />
    <input type="submit" name="upload" class="btn btn-info" value="Upload" />
   </form>
   <br />
   <?php echo $message; ?>
   <h3 align="center">Results Table</h3>
   <br />
   <div class="table-responsive">
    <table class="table table-bordered table-striped">
     <tr>
      <th>Htno</th>
      <th>Subcode</th>
      <th>Subname</th>
      <th>Grade</th>
      <th>Credits</th>
     </tr>
     <?php
     while($row = mysqli_fetch_array($result))
     {
      echo '
      <tr>
       <td>'.$row["Htno"].'</td>
       <td>'.$row["Subcode"].'</td>
       <td>'.$row["Subname"].'</td>
       <td>'.$row["Grade"].'</td>
       <td>'.$row["Credits"].'</td>
      </tr>
      ';
     }
     ?>
    </table>
   </div>
  </div>
 </body>
</html>
