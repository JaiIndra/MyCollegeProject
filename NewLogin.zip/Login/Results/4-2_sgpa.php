<html>
<head>
<title> S.R.K IT DEPT</title>
 <style>
body{
    margin: 0;
  padding: 0;
  font-family: sans-serif;
  background-color:#48C9B0;
background-size: cover;
  
}
 table,th,td{
   border: 2px solid black;
   width : 650px;
 background-color: white;
}
.btn{
width: 10;
height:5%;
font-size:22px;
padding:0px;

}
</style>
</head>
<body>
 <!-- Page Content -->
    <div class="container">
  <div class="sidebar-brand">
             <h1><span clas="lab la-accsoft"></span> Another Details</h1>
        </div>
        <div class="sidebar-menu">
            <ul>
               
                <p>
                   <a href="https://www.jntufastupdates.com/jntuk-time-tables/"><span class="las la-users"></span>
                      <h2>Exam Time Tables</h2>
                    </a>
                    </p>

                
                <p>
                   <a href="../index.html">LogGout
                      
                    </a>
                    </p>
            
               
                
              </div>
          </div>
  
    	<center>
		
						
				<div class="table-responsive">
					<table id="table" class="table-bordered table-striped">
                                               <tr>
                                              <th>Htno</th>
                                              <th>Subcode </th>
	           			      <th>Subname </th>
				 	      <th>Grade </th>
					      <th>Credits </th>
                                          <th>GradePoints</th><br>
						<th>Total</th><br>
		<?php
 
					$conn = mysqli_connect("localhost","root","");
					$db = mysqli_select_db($conn, 'javapoint'); 
                                session_start();
                                 $Htno= $_SESSION['rollno'];
					
					$query = "SELECT * FROM `4-2results` WHERE Htno = '$Htno'";
                                        
					$query_run = mysqli_query($conn,$query);
					
				
				while($row = mysqli_fetch_array($query_run)){
										          
						
                				
						?>
							
							<tr>
							  <td> <?php echo $row['Htno']; ?> </td>
							  <td> <?php echo $row['Subcode']; ?> </td>
							  <td> <?php echo $row['Subname']; ?> </td>
							  <td> <?php echo $row['Grade']; ?> </td>
							  <td> <?php echo $row['Credits']; ?> </td>
<td><?php
$Grade = $row['Grade'];
$Gradepoint=0;
if ($Grade =='COMPLETED'){
$Gradepoint=0;}
if ($Grade =='O'){
$Gradepoint=10;}
if ($Grade =='S'){
$Gradepoint=9;}
if ($Grade =='A'){
$Gradepoint=8;}
if ($Grade =='B'){
$Gradepoint=7;}
if ($Grade =='C'){
$Gradepoint=6;}
if ($Grade =='D'){
$Gradepoint=5;}
if ($Grade =='F'){
$Gradepoint=0;}
$count=0;
 $sum=$row['Credits']*$Gradepoint;
echo $sum;
?></td>		
<td><?php
  
$conn = mysqli_connect("localhost","root","");
					$db = mysqli_select_db($conn, 'javapoint'); 
          
$query2 = "SELECT SUM(Credits) AS sum,Grade from `4-2results` WHERE Htno = '$Htno'";
                                        
	$query_run2 = mysqli_query($conn,$query2);

while($row = mysqli_fetch_array($query_run2)){

  $output = $row['sum'];
echo $output;

}
?></td>
					 </tr>
					<?php
			
			}	
 
					?>   

						</table>
				</tr>
			</tbody></br>
       <span id="val"></span>
			
	   
                   
        <script>
            
            var table = document.getElementById("table"), sumVal = 0  ;Total=0;
            
            for(var i = 1; i < table.rows.length; i++)
            {
                sumVal = sumVal + parseInt(table.rows[i].cells[5].innerHTML);
                 
            }
                     Total = Total + parseInt(table.rows[3].cells[6].innerHTML);        
                          
            document.getElementById("val").innerHTML = "Total SGPA = " + sumVal/Total;
            console.log(sumVal);
            
        </script>
<br>
        <input type="button" onclick="window.print()" class="ci" value="Print Result"></th></tr></tbody></table></div>
			<br>


</body>
</html>


 

